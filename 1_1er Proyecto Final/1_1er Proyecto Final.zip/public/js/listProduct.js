const btnRemove = (e, id) => {
  const fetchDELETE = {
    method: "DELETE",
  }

  fetch(`http://localhost:8080/api/products/${id}`, fetchDELETE).then(
    setTimeout(() => {
      location.reload()
    }, 500)
  )
}
